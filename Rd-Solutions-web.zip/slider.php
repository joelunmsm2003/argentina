<?php

  require_once('api/inicio.php');


  //////////////////////////////////
 /// Configuración de la página ///
//////////////////////////////////

  define('SECCION', 'slider');

// Fin configuración de la página //

  include('header.php');

?>

<article>
	<div class="container">
		<h2>Da super duper Slider</h2>
		<h3>Prósimamente</h3>
	</div>
</article>

<?php include('footer.php'); ?>