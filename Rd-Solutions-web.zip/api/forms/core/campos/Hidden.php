<?php

/** Campo oculto
*
*/
Class Input_hidden extends Input_text{}
