<?php

/** Campo de contraseña
*
*/
Class Input_password extends Input_text{}

