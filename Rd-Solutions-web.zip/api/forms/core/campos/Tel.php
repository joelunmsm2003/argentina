<?php

/** Campo de teléfono
*
*/
Class Input_tel extends Input_text{}

