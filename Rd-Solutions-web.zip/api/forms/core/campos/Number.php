<?php

/** Campo números
*
*/
Class Input_number extends Input_text{}
