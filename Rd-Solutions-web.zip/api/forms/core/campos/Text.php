<?php

/** Campo de texto
*
*/
Class Input_text extends Campo{}
