<?php

/** Campo radio
*
*/
Class Input_radio extends Input_text{}