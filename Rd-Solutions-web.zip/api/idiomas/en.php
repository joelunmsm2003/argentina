<?php 

// return include('es.php'); En caso de no contar con los textos traducidos, dejar este archivo vacio y descomentar esta linea

return include('es.php');

 ?>