<?php

/*
* --------------------------------------------------------------------------
* BASE DE DATOS
* --------------------------------------------------------------------------
*
* Datos de conexión a la base de datos
*
*/

return array(

	'hostname' => 'localhost',
	'database' => 'solution_db',
	'username' => 'solution_db',
	'password' => 'd0shJH%1v7J8',
	'charset'  => 'utf8',

);
