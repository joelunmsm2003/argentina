<?php

/* 
* --------------------------------------------------------------------------
* FORMULARIOS
* --------------------------------------------------------------------------
*
*/

return array(

	/*
	* CLAVES CAPTCHA DE GOOGLE
	* Sirve para todos los formularios del sitio. Creá las claves desde 
	* https://www.google.com/recaptcha/admin#list
	*
	* Si no cargás claves se usan unas de prueba que funcionan pero te 
	* imprimen un mensaje en rojo arriba del CAPTCHA.
	*
	*/
	'captcha_site_key' => '6Lda_z8UAAAAAEI_Y08gXYAt5bXO8vJcbA1ozmXO',
	'captcha_secret_key' => '6Lda_z8UAAAAAJg9sm2DAqE804s5yDq3F4qOfnpP',
	
);