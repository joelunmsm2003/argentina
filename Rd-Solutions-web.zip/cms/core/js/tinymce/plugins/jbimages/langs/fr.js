/**
 * Justboil.me - a TinyMCE image upload plugin
 * jbimages/langs/fr.js
 *
 * Released under Creative Commons Attribution 3.0 Unported License
 *
 * License: http://creativecommons.org/licenses/by/3.0/
 * Plugin info: http://justboil.me/
 * Author: Viktor Kuzhelnyi
 *
 * Version: 2.3 released 23/06/2013
 */

tinyMCE.addI18n('fr.jbimages',{
	desc : 'T\u00E9l\u00E9charger une image'
});