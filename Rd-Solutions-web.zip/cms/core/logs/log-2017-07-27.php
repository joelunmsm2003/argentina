<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-07-27 15:07:28 --> Campo file_upload: La extensión "imagick" no está habilitada.
ERROR - 2017-07-27 15:07:28 --> Upload File: {"success":true,"newFilename":"2MB- Brochure-A4-final-DIGITAL-nuevotel.pdf","archivo_id":69}
ERROR - 2017-07-27 18:23:46 --> Upload File: {"success":true,"newFilename":"20375575893_011_00001_00000005 (1).pdf","archivo_id":70}
ERROR - 2017-07-27 18:25:13 --> Upload File: {"success":true,"newFilename":"recibos-0417-0617.pdf","archivo_id":71}
ERROR - 2017-07-27 18:29:08 --> Severity: Notice  --> Undefined property: stdClass::$pdf /home/base/public_html/cms/core/core/MY_Controller.php 637
ERROR - 2017-07-27 19:09:29 --> Upload File: {"success":true,"newFilename":"recibos-0417-0617.pdf","archivo_id":72}
ERROR - 2017-07-27 19:10:25 --> Upload File: {"success":true,"newFilename":"2MB- Brochure-A4-final-DIGITAL-nuevotel.pdf","archivo_id":73}
