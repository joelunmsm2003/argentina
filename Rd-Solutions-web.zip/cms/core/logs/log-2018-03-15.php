<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-03-15 16:52:41 --> 404 Page Not Found --> idioma=es
