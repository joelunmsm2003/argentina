<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-02-02 13:11:48 --> Severity: Notice  --> Undefined property: stdClass::$titulo /home/solutionsrd/public_html/cms/core/views/includes/lista/campos.php 72
ERROR - 2018-02-02 13:11:48 --> Severity: Notice  --> Undefined property: stdClass::$titulo /home/solutionsrd/public_html/cms/core/views/includes/lista/campos.php 72
ERROR - 2018-02-02 13:11:48 --> Severity: Notice  --> Undefined property: stdClass::$titulo /home/solutionsrd/public_html/cms/core/views/includes/lista/campos.php 72
