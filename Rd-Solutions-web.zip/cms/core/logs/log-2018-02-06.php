<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-02-06 18:19:46 --> 404 Page Not Found --> idioma=es
ERROR - 2018-02-06 18:19:56 --> 404 Page Not Found --> idioma=en
ERROR - 2018-02-06 18:20:57 --> 404 Page Not Found --> idioma=en
