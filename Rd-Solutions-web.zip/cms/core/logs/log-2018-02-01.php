<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-02-01 17:17:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/solutionsrd/public_html/cms/core/controllers/novedades.php:1) /home/solutionsrd/public_html/cms/libs/codeigniter/libraries/Session.php 675
ERROR - 2018-02-01 17:18:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/solutionsrd/public_html/cms/core/controllers/novedades.php:1) /home/solutionsrd/public_html/cms/libs/codeigniter/helpers/url_helper.php 540
ERROR - 2018-02-01 17:18:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/solutionsrd/public_html/cms/core/controllers/novedades.php:1) /home/solutionsrd/public_html/cms/libs/codeigniter/helpers/url_helper.php 540
ERROR - 2018-02-01 17:18:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/solutionsrd/public_html/cms/core/controllers/novedades.php:1) /home/solutionsrd/public_html/cms/core/core/MY_Controller.php 1488
ERROR - 2018-02-01 17:18:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /home/solutionsrd/public_html/cms/core/controllers/novedades.php:1) /home/solutionsrd/public_html/cms/libs/codeigniter/helpers/url_helper.php 540
ERROR - 2018-02-01 17:28:34 --> 404 Page Not Found --> novedades/clone
